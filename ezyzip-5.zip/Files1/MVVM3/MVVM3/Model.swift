//
//  Model.swift
//  MVVM3
//
//  Created by rasim rifat erken on 2.08.2022.
//

import Foundation



struct School : Codable {
    var data : [VehicleData]?
}

struct VehicleData: Codable {
    
    var attributes: RealData?
    
}

struct RealData : Codable {
    var vehicle_title : String?
}
