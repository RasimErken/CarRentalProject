//
//  ViewModel.swift
//  MVVM3
//
//  Created by rasim rifat erken on 2.08.2022.
//

import Foundation



class NYCViewModel {
    
    static let instance = NYCViewModel()
    
    
    var schoolModel : [VehicleData]?
    
    func getALLData(completionHandler: @escaping () -> () ) {
        
        guard let url = URL(string: "https://search.outdoorsy.com/rentals") else {
            print("FailToUrl")
            return
        }

        
        URLSession.shared.dataTask(with: url) { ( data, response, error ) in
            guard let data = data else { return }
            let jsonDecoder = JSONDecoder()
            do {
                let finalData = try jsonDecoder.decode(School.self, from: data)
                print(finalData)
                self.schoolModel = finalData.data
                completionHandler()
            } catch  {
                print(error, "Couldn't be parsed correctly")
            }
                
            

        } .resume()
        
    }

    
    
    
}
