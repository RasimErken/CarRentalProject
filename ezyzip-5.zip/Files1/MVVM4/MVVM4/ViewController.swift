//
//  ViewController.swift
//  MVVM4
//
//  Created by rasim rifat erken on 6.08.2022.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate , UITableViewDataSource {

    
    var DataArray = [VehicleData]()
    
    let tableView: UITableView = {
        let table = UITableView()
        table.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        return table
    }()
    
    let search :UISearchBar = UISearchBar()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(tableView)
        
        
        tableView.delegate = self
        tableView.dataSource = self
        
        
        
        
        
        
        
            
        tableView.rowHeight = 200
        tableView.estimatedRowHeight = 200
        displayloginfields()
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        DataService.instance.getData(withUrl: Vehicle_URL!) {vehiclelist in
            self.DataArray = vehiclelist
            self.tableView.reloadData()
            
        }
    }
    
    
    
    
    
    func displayloginfields(){
        search.placeholder = "Search"
        search.backgroundColor = UIColor.gray
        self.view.addSubview(search)
    }
    
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.frame = CGRect(x: 0, y: 200, width: self.view.frame.width, height: 600)
        
        search.frame = CGRect(x: 100, y: 120, width: 240, height: 50)
        search.layer.cornerRadius = search.frame.size.height/2
        search.clipsToBounds = true
        
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let a = DataArray[indexPath.row].attributes?.vehicle_title
        
        cell.textLabel?.text = a
        cell.imageView?.image = UIImage(systemName: "house")
        cell.imageView?.tintColor = .systemBlue
        return cell
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }




    
    


}

