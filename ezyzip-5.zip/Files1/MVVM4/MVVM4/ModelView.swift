//
//  ModelView.swift
//  MVVM4
//
//  Created by rasim rifat erken on 6.08.2022.
//

import Foundation

protocol SessionProtocol {
    func dataTask(with url : URL, completionHandler : @escaping (Data?, URLResponse?, Error?)->()) -> URLSessionDataTask
}

class DataService {
    
    static let instance = DataService()
    
    var session : SessionProtocol = URLSession.shared
    
    var a = [VehicleData]()
    
    func getData(withUrl url : URL, completion :@escaping(_ vehiclelist : [VehicleData])->()) {
        
        
        
        session.dataTask(with: url) { data, response, error in
            if error != nil {
                print(error!, "Data couldn't be fetched")
            } else {
                guard let data = data else { print("no data") ; return }
                
                let decoder = JSONDecoder()
                do {
                   let vehicleList =  try decoder.decode(School.self, from: data)
                    self.a = vehicleList.data!
                    completion(self.a)
                } catch  {
                    print(error, "Couldn't be parsed correctly")
                }
            }
        }.resume()
    }
}

extension URLSession : SessionProtocol {}

