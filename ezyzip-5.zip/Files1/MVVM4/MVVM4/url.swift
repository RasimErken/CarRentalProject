//
//  url.swift
//  MVVM4
//
//  Created by rasim rifat erken on 6.08.2022.
//

import Foundation

var Vehicle_URL = URL(string: "https://search.outdoorsy.co/rentals")
