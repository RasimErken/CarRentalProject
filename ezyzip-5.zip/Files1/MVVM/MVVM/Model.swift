//
//  Model.swift
//  MVVM
//
//  Created by rasim rifat erken on 30.07.2022.
//

import Foundation




struct School : Codable {
   
  
    var school_name : String
    
}






